export const minecraftColors = [
  { name: "White", hex: "#F9FFFE" },
  { name: "Orange", hex: "#F9801D" },
  { name: "Magenta", hex: "#C74EBD" },
  { name: "Light Blue", hex: "#3AB3DA" },
  { name: "Yellow", hex: "#FED83D" },
  { name: "Lime", hex: "#80C71F" },
  { name: "Pink", hex: "#F38BAA" },
  { name: "Gray", hex: "#474F52" },
  { name: "Light Gray", hex: "#9D9D97" },
  { name: "Cyan", hex: "#169C9C" },
  { name: "Purple", hex: "#8932B8" },
  { name: "Blue", hex: "#3C44AA" },
  { name: "Brown", hex: "#835432" },
  { name: "Green", hex: "#5E7C16" },
  { name: "Red", hex: "#B02E26" },
  { name: "Black", hex: "#1D1D21" }
];