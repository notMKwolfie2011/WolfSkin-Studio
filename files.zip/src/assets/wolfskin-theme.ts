export const wolfskinTheme = {
  colors: {
    primary: "#6D47A7",
    accent: "#A19BD9",
    background: "#232332",
    panel: "#27273C",
    highlight: "#F9801D",